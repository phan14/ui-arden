<?php
/** Template Name: Arden Search Landing */

defined( 'ABSPATH' ) || exit;
get_header();
arden_page_banner( 'TÌM KIẾM THÔNG MINH', 'TÌM KIẾM NỘI DUNG ARDEN', 'Tra cứu dịch vụ, dự án mẫu và kiến thức sản xuất may mặc.' );

$arden_search_query = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : 'áo thun';
$arden_results      = new WP_Query(
	array(
		'post_type'      => array( 'page', 'post', 'project' ),
		'post_status'    => 'publish',
		'posts_per_page' => 12,
		's'              => $arden_search_query,
	)
);
?>
<main class="arden-page arden-react-page">
	<section class="arden-section arden-search-page"><div class="arden-container">
		<form class="arden-search-page__form" action="<?php echo esc_url( get_permalink() ); ?>" method="get" role="search">
			<label for="arden-search-query">Từ khóa tìm kiếm</label>
			<div class="arden-search-page__control"><input id="arden-search-query" name="q" type="search" value="<?php echo esc_attr( $arden_search_query ); ?>" placeholder="Nhập sản phẩm, chất liệu hoặc kiến thức cần tìm…"><button class="arden-button" type="submit">TÌM KIẾM</button></div>
		</form>
		<div class="arden-search-tabs" role="tablist" aria-label="Lọc kết quả tìm kiếm">
			<button type="button" class="is-active" role="tab" aria-selected="true" data-search-type="all">TẤT CẢ</button>
			<button type="button" role="tab" aria-selected="false" data-search-type="page">DỊCH VỤ</button>
			<button type="button" role="tab" aria-selected="false" data-search-type="project">DỰ ÁN</button>
			<button type="button" role="tab" aria-selected="false" data-search-type="post">KIẾN THỨC</button>
		</div>
		<div class="arden-content-grid" data-search-results>
			<?php if ( $arden_results->have_posts() ) : ?>
				<?php while ( $arden_results->have_posts() ) : $arden_results->the_post(); ?>
					<article class="arden-card arden-content-card" data-result-type="<?php echo esc_attr( get_post_type() ); ?>">
						<a class="arden-card__media" href="<?php the_permalink(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'arden-card' ); } else { echo '<span class="arden-card__placeholder" aria-hidden="true"></span>'; } ?></a>
						<div class="arden-card__body"><p class="arden-card__meta"><?php echo esc_html( 'project' === get_post_type() ? 'Dự án' : ( 'post' === get_post_type() ? 'Kiến thức' : 'Dịch vụ' ) ); ?></p><h2 class="arden-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p class="arden-card__excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p></div>
					</article>
				<?php endwhile; ?>
			<?php else : ?>
				<p class="arden-empty">Không tìm thấy nội dung phù hợp.</p>
			<?php endif; wp_reset_postdata(); ?>
		</div>
	</div></section>
</main>
<?php get_footer(); ?>
